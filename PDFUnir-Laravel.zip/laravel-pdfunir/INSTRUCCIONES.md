# PDFUnir — Laravel + iLovePDF API

## 1. Instalar el SDK
```bash
composer require ilovepdf/ilovepdf-php
```

## 2. Añadir claves al .env
```
ILOVEPDF_PUBLIC_KEY=project_public_xxxxxxxxxxxxxxxxxxxxxxxxx
ILOVEPDF_SECRET_KEY=secret_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```
Consíguelas gratis en: https://developer.ilovepdf.com

## 3. Añadir a config/services.php
```php
'ilovepdf' => [
    'public_key' => env('ILOVEPDF_PUBLIC_KEY'),
    'secret_key' => env('ILOVEPDF_SECRET_KEY'),
],
```

## 4. Copiar archivos
- `PdfController.php`  →  `app/Http/Controllers/`
- `index.blade.php`    →  `resources/views/pdf/`
- Añadir rutas de `web.php` a tu `routes/web.php`

## 5. Crear directorio temporal
```bash
mkdir -p storage/app/tmp
```
(Laravel lo limpia solo, pero puedes añadir un comando artisan si quieres limpieza programada)

## 6. Ajustar límites en php.ini / Plesk
Para ZIPs de hasta 120 MB necesitas en Plesk → PHP Settings:
```
upload_max_filesize = 200M
post_max_size       = 250M
max_execution_time  = 120
```

## Niveles de compresión iLovePDF
| Valor        | Descripción                        |
|--------------|------------------------------------|
| recommended  | Mejor equilibrio (recomendado)     |
| extreme      | Máxima compresión, algo más pérdida|
| low          | Mínima pérdida, menos compresión   |

## Plan gratuito iLovePDF
- 250 operaciones/mes gratis
- Cada merge = 1 operación
- Cada compress = 1 operación
- Con compress activado: cada proceso usa 2 operaciones
