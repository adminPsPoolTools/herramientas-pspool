<?php
// Añade esto dentro del array 'return [...]' de config/services.php

'ilovepdf' => [
    'public_key' => env('ILOVEPDF_PUBLIC_KEY'),
    'secret_key' => env('ILOVEPDF_SECRET_KEY'),
],
