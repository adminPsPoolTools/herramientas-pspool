<?php
// Añade estas líneas a tu routes/web.php

use App\Http\Controllers\PdfController;

Route::get('/pdf-unir',          [PdfController::class, 'index'])->name('pdf.index');
Route::post('/pdf-unir/merge',   [PdfController::class, 'merge'])->name('pdf.merge');
